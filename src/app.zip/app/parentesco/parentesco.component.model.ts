export class Parentesco {

	parentescoId: number = null;
	conyuge: string = '';
	ascendiente: string = '';
	hijo: string = '';



}
