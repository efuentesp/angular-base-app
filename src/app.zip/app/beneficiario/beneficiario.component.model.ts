export class Beneficiario {

	beneficiarioId: number = null;
	apellido_materno: string = '';
	curp: string = '';
	fecha_nacimiento: string = '';
	nombre: string = '';
	apellido_paterno: string = '';

	parentescoId: number = null;	


}
