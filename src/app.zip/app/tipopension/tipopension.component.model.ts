export class Tipopension {

	tipopensionId: number = null;
	nombre: string = '';
	clave: string = '';



}
