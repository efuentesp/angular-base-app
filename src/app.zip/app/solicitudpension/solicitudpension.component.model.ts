export class Solicitudpension {

	solicitudpensionId: number = null;
	numero: string = '';
	observaciones: string = '';
	fecha_solicitud: string = '';

	afiliadoId: number = null;
	tipopensionId: number = null;


}
