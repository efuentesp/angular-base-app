export class Afiliado {

	afiliadoId: number = null;
	fecha_afiliacion: string = '';
	foto: string = '';
	correo: string = '';
	apellido_materno: string = '';
	acta_nacimiento: string = '';
	monto_pension: string = '';
	apellido_paterno: string = '';
	observaciones: string = '';
	nombre: string = '';
	semanas_cotizadas: string = '';
	nss: string = '';

	generoId: number = null;	
	beneficiarioId: number = null;


}
