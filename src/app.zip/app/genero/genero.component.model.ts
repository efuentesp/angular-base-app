export class Genero {

	generoId: number = null;
	female: string = '';
	male: string = '';



}
